# Mathematics

**Repository dedicated to mathematical calculations**

as update of 31st oct
>>Added program ability to calculate trigonometric functions. such as sin,cos,tan etc.
>>Added program ability to calculate arc tangent of T ratios.
>>Will be adding more functionality to make complex mathematical calculations :)
>>User friendly and less bugs
Make sure you keep **main.cpp** and **FunsNClasses.cpp** together in the same folder ;)
![Mathematics](https://user-images.githubusercontent.com/91114837/139595859-d2406f55-1cdd-4869-b9fc-93d4442358a7.PNG)

I combined all my knowledge to make this program.
When this repository was private i gave it a lot of updates, i wrote all this code by myself as you can
guess that because the code is very simple and straight and i kept the function and variable and classes names
very simple and easy to understand.

Make sure you read capabilities and limitations of the program i made. :)

WHAT THIS PROGRAM IS CAPABLE OF?
With the new code and new function added now you will be able to do more calculations such as-
Squares:
1.You can now find Area of squares.
2.You can now also find perimeter of squares.

Triangles:
1.Now you can find perimeter of triangle.
2.You can find area of triangle.
3.You can also find area of triangle using HERON's formula!

Rectangles:
1.You can find area of rectangle.
2.You can find diagonal of rectangle.
3.You can also find perimeter of rectangle.

Circle:
1.You can find area of circle.
2.You can also find circumference of circle.

# Limitations of this program. 
Obviously with reasons.
2.I am still in my learning age, i used all my knowledge and tricks to make this program as good as i could
some of the problems i could not fix were
(i): there is use of tons of same code lines again. i dont know but i used a lot of code and variables again and again which was
annoying and i didnt know how can i replace it.
(ii): there is not much complexity of code and it is very very basic code, because all it does is maths.

3.Once you make a choice you cannot go back, if you chose calculations for Square you cannot go back, eithe
4.The main problem is, if user enters invalid input the code is not able to handle it and just exits on its own, yes
there are no do or while loops you know the reason. Yeah the code will not be able to handle wrong or invalid input and
will just crash, not pog.
